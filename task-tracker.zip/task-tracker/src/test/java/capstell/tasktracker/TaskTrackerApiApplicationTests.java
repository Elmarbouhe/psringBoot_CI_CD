package capstell.tasktracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskTrackerApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
