package capstell.tasktracker.CustomValidation;


import capstell.tasktracker.CustomAnotation.CapgeminiEmail;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class EmailConstraintValidator implements ConstraintValidator<CapgeminiEmail, String> {
    @Override
    public void initialize(CapgeminiEmail constraintAnnotation) {
    }

    @Override
    public boolean isValid(String email, ConstraintValidatorContext constraintValidatorContext) {
        return email != null && email.endsWith("@capgemini.com");
    }
}
