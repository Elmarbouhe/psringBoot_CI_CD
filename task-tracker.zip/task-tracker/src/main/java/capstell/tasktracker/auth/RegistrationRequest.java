package capstell.tasktracker.auth;

import capstell.tasktracker.CustomAnotation.CapgeminiEmail;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
public class RegistrationRequest {

    @NotEmpty(message = "First name is required")
    @NotBlank(message = "First name is mandatory")
    private String firstname;

    @NotEmpty(message = "Last name is required")
    @NotBlank(message = "Last name is mandatory")
    private String lastname;

    @NotEmpty(message = "Email is required")
    @NotBlank(message = "Email is mandatory")
    @Email(message = "Email should be end with @gmail.com")
    @CapgeminiEmail(message = "Email must end with @capgemini.com")
    private String email;
    @NotEmpty(message = "Last name is required")
    @NotBlank(message = "Last name is mandatory")
    @Size(min = 8, max = 16, message = "Password should be between 8 and 16 characters")
    private String password;

}
