package capstell.tasktracker.auth;

import capstell.tasktracker.email.EmailService;
import capstell.tasktracker.email.EmailTemplateName;
import capstell.tasktracker.role.RoleRepository;
import capstell.tasktracker.user.Token;
import capstell.tasktracker.user.TokenRepository;
import capstell.tasktracker.user.User;
import capstell.tasktracker.user.UserRepository;
import jakarta.mail.MessagingException;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class AuthenticationService {

    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;
    private final UserRepository userRepository;
    private final TokenRepository tokenRepository;
    private final EmailService emailService;

    @Value("${application.mailing.frontend.activation-url}")
    private String activationUrl;
    public void register(RegistrationRequest request) throws MessagingException {
        // SET DEFAULT ROLE TO USER
        var userRole = roleRepository.findByName("USER")
                // TODO Better exception handling
                .orElseThrow(() -> new IllegalStateException("Role not found"));
        // CREATE USER
        var user = User.builder()
                .firstname(request.getFirstname())
                .lastname(request.getLastname())
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .accountLocked(false)
                .enabled(false) // User is not enabled until they validate their email
                .roles(List.of(userRole))
                .build();
        // SAVE USER
        userRepository.save(user);
        // SEND VALIDATION EMAIL
        sentValidationEmail(user);
    }

    private void sentValidationEmail(User user) throws MessagingException {
        var newToken =  generateAndSaveActivationToken(user);
        // SEND EMAIL
        emailService.sendEmail(
                user.getEmail(),
                user.fullName(),
                EmailTemplateName.ACTIVATE_ACCOUNT,
                activationUrl,
                newToken,
                "Account Activation"
        );
    }

    // This method generates an activation token for the user and saves it to the database
    private String generateAndSaveActivationToken(User user) {
        // GENERATE TOKEN
        String GeneratedToken = generateActivationCode(6);
        var token = Token.builder()
                .token(GeneratedToken)
                .createdAt(LocalDateTime.now())
                .expiresAt(LocalDateTime.now().plusMinutes(15)) // Token expires in 15 minutes
                .user(user)
                .build();
        tokenRepository.save(token);
        return GeneratedToken;
    }

    // This method generates a random activation code of a specified length
    private String generateActivationCode(int length) {
        // Define the characters that can be used in the activation code
        String characters = "0123456789";

        // StringBuilder is used to efficiently build strings
        StringBuilder codeBuilder = new StringBuilder();

        // SecureRandom provides a cryptographically strong random number generator
        SecureRandom secureRandom = new SecureRandom();

        // Loop 'length' times to generate each character of the code
        for (int i = 0; i < length; i++) {
            // Generate a random index within the range of the characters string
            int randomIndex = secureRandom.nextInt(characters.length());

            // Append the character at the random index to the codeBuilder
            codeBuilder.append(characters.charAt(randomIndex));
        }

        // Convert the codeBuilder to a string and return the generated activation code
        return codeBuilder.toString();
    }

}
